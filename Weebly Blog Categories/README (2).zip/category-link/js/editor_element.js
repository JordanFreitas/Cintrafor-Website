/**
 * This is required for element rendering to be possible
 * @type {PlatformElement}
 */
(function() {
    var CategoryLink = PlatformElement.extend({
        initialize: function() {
            // set up our handlers
            this.setUpEvents();
        },

        /**
         * Lots of styles are applied by default to editable areas of
         * the editor. To make the element looks how you want, some styles
         * need to be overwritten.
         *
         * Classes that are used are:
         *      - .editable-text
         *      - .paragraph
         *      - .ui-wrapper
         *      - .wsite-image
         *      - .wsite-*
         *      - (etc...)
        */
        // sets up the image for proper usage.
        setUpEvents: function() {
            // var $imgContainer = this.$('.team-card__image--' + this.settings.get('image_display'));
            var check = this.settings.get('category');
            var blog = this.settings.get('blog');

            // var page = new Webpa
            $.get( "https://cintrafor.weebly.com/publications/category/china", function( data ) {
                // $( ".result" ).html( data );
                console.log(data);
                alert( "Load was performed." );
              });

            console.log("here we goooo" + blog + check);

        },

    });

    return CategoryLink;
})();
#Tabs

Display a subheader of tabs

The Tabs app is great for product pages, or anywhere you want to show related information but in an organized and thoughtful design. Arrange extensive information in easy to navigate tabs that allows the user to choose the information that’s most important to them with the corresponding info beneath it.

Customize the Tabbed Boxes to match your site. Want the tabs on the left or the bottom of the box? Change it up to have them displayed how you want. The app also has four different tab styles to choose from; standard, 3D, line, and simple. 
